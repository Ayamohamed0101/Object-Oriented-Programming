/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;

/**
 *
 * @author h
 */
public class Project3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    FloatNumber f1=new FloatNumber(53874,2);
    FloatNumber f2=new FloatNumber(553.27);
    FloatNumber f=f2.MulInt(3);
    f1.show();
   // System.out.println(f.getval()+" ddd "+f.getndp());
    
    }
}
